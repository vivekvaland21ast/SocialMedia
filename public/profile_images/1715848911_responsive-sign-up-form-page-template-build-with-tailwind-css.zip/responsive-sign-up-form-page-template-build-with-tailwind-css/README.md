# Responsive Sign Up Form Page Template Build With Tailwind CSS

A Pen created on CodePen.io. Original URL: [https://codepen.io/owaiswiz/pen/jOPvEPB](https://codepen.io/owaiswiz/pen/jOPvEPB).

This is a free to use simple responsive sign up form page template built entirely with stock tailwindcss. MIT License, free for commercial/personal use. 

It can also be customized to be used as a login form